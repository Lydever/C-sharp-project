# MyCinema
C#实现的影院售票系统。