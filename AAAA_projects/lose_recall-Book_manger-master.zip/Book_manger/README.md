# Book_manger

#### 介绍
C#与 SQL 实现简约版图书管理系统

### [运行视频](https://www.bilibili.com/video/BV1TZ4y1H7FR/)
### 运行效果截图
![登录](https://images.gitee.com/uploads/images/2020/0615/105024_0c899216_7510148.png "QQ截图20200615104751.png")
![管理员选项](https://images.gitee.com/uploads/images/2020/0615/105113_49df6cc9_7510148.png "QQ截图20200615104818.png")
![图书](https://images.gitee.com/uploads/images/2020/0615/105128_c83ffb23_7510148.png "QQ截图20200615104831.png")
![借阅](https://images.gitee.com/uploads/images/2020/0615/105139_c50180bc_7510148.png "QQ截图20200615104842.png")
![类别](https://images.gitee.com/uploads/images/2020/0615/105154_75a8c429_7510148.png "QQ截图20200615104857.png")
![读者](https://images.gitee.com/uploads/images/2020/0615/105209_de4530aa_7510148.png "QQ截图20200615104908.png")




