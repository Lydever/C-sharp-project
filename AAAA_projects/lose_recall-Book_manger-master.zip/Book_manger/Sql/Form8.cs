﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sql
{
    public partial class Form8 : Form
    {
        string user, num;

        private void Form8_Load(object sender, EventArgs e)
        {
            label1.Text = user;
            label2.Text = num;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2(user,num);
            form.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form7 form = new Form7(user,num);
            form.Show();
            this.Hide();
        }

        private void Form8_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }

        public Form8(string u,string n)
        {
            InitializeComponent();
            user = u;
            num = n;
        }
    }
}
