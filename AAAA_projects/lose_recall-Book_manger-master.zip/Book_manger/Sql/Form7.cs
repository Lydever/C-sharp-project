﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sql
{
    public partial class Form7 : Form
    {
        string user, no,name;
        public Form7(string us,string n)
        {
            InitializeComponent();
            user = us;
            no = n;
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            label1.Text = user;
            label2.Text = no;
            BindGrid();
            timer1.Start();
            timer1_Tick(null,null);
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string sqlStr = "update Borrow set Return_date='" + DateTime.Now.ToString("yyyy-MM-dd") + "'where B_name='"+name+"'";
            if(SQL.SqlUpdate(sqlStr))
                MessageBox.Show("更新成功");
            Form7_Load(this, null);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            getselectdata();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form8 form = new Form8(user, no);
            form.Show();
            this.Hide();
        }

        private void Form7_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        void BindGrid()
        {
            try
            {
                SQL.Open();
                SqlCommand lo_cmd = new SqlCommand();
                lo_cmd.CommandText = "select * from Borrow where R_no='"+no+"'";
                lo_cmd.Connection = SQL.conn;
                lo_cmd.ExecuteNonQuery();
                SqlDataAdapter dbAdapter = new SqlDataAdapter(lo_cmd);
                DataSet ds = new DataSet();
                dbAdapter.Fill(ds);
                SQL.Close();
                dataGridView1.DataSource = ds.Tables[0];
            }
            catch
            {
                MessageBox.Show("异常");
            }

        }
        void getselectdata()
        {
            int a = dataGridView1.CurrentRow.Index;
            name = dataGridView1.Rows[a].Cells["B_name"].Value.ToString();


        }
    }
}
