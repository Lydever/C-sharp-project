﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sql
{
    public partial class Form5 : Form
    {
        string name,Book_name;
        public Form5(string u)
        {
            InitializeComponent();
            name = u;
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            label2.Text = name;
            BindGrid();
            timer1.Start();
            timer1_Tick(null,null);
        }
        void BindGrid()
        {
            SQL.Open();
            SqlCommand lo_cmd = new SqlCommand();
            lo_cmd.CommandText = "select * from Borrow ";
            lo_cmd.Connection = SQL.conn;
            lo_cmd.ExecuteNonQuery();
            SqlDataAdapter dbAdapter = new SqlDataAdapter(lo_cmd);
            DataSet ds = new DataSet();
            dbAdapter.Fill(ds);
            SQL.Close();
            dataGridView1.DataSource = ds.Tables[0];
        }
        void getselectdata()
        {
            int a = dataGridView1.CurrentRow.Index;
            textBox1.Text = dataGridView1.Rows[a].Cells["R_no"].Value.ToString();
            Book_name = dataGridView1.Rows[a].Cells["B_name"].Value.ToString();

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            getselectdata();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //string sqlStr = "update Borrow set B_name='数据库',Borrow_days=20 where R_no='182056204'";
            string sqlStr = "update Borrow set B_name='" + textBox2.Text  
                + "',Borrow_days=" + textBox4.Text+",Borrow_date='"+textBox3.Text + ",Return_date='" + textBox5.Text
                + "'where R_no='" + textBox1.Text + "'and B_name='"+Book_name+"'";
            if(SQL.SqlUpdate(sqlStr))
                MessageBox.Show("更新成功");
            Form5_Load(this, null);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string sqlStr = "delete from Borrow where R_no='" + textBox1.Text + "'and B_name='" + Book_name + "'";
            if(SQL.SqlDelete(sqlStr))
                MessageBox.Show("删除成功");
            Form5_Load(this, null);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form9 form = new Form9(name);
            form.Show();
            this.Hide();
        }

        private void Form5_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string sqlInsert = "insert into Borrow values('" + textBox6.Text + "','" + textBox7.Text + "','" + textBox8.Text + "','" + textBox9.Text + "' ,null)";

            if(SQL.SqlInsert(sqlInsert))
                MessageBox.Show("添加成功");
            Form5_Load(this, null);
        }
    }
}
