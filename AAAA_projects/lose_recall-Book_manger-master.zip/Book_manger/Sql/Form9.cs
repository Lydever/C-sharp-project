﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sql
{
    public partial class Form9 : Form
    {
        string user;
        public Form9(string name)
        {
            InitializeComponent();
            user = name;
        }

        private void Form9_Load(object sender, EventArgs e)
        {
            label2.Text = user;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 form = new Form3(user);
            form.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form4 form = new Form4(user);
            form.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form5 form = new Form5(user);
            form.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form6 form = new Form6(user);
            form.Show();
            this.Hide();
        }

        private void Form9_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }
    }
}
