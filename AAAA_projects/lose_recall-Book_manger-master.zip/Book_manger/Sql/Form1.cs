﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sql
{
    public partial class Form1 : Form
    {
        bool flag = false;
        bool flags = false;
        bool change = false;
        public Form1()
        {
            InitializeComponent();
            
        }
        void select()
        {
            string keys = "SELECT R_no FROM Reader WHERE R_no ='" + textBox3.Text + "'";
            //调用查询语句从user表查询type=管理
            string colums = "R_no";
            if (SQL.Querys(keys, colums))
            {
                //MessageBox.Show(keys);
                flags = true;
            }
            if (change==true)
            {
                string sqlStr = "SELECT Username FROM Users WHERE Typer ='" + radioButton2.Text + "'and Username='" + textBox1.Text + "'and Passwords='" + textBox2.Text + "'";
                
                //调用查询语句从user表查询type=管理员
                
                string colum = "Username";
                if (SQL.Querys(sqlStr, colum))
                {
                    //MessageBox.Show(sqlStr);
                    flag = true;
                }

            }
            else
            {
                string key = "SELECT Username FROM Users WHERE Typer ='" + radioButton1.Text + "'and Username='" + textBox1.Text + "'and Passwords='" + textBox2.Text + "'";
                //调用查询语句从user表查询type=管理员
                string colum = "Username";
                if (SQL.Querys(key, colum))
                {
                    //MessageBox.Show(key);
                    flag = true;
                }

            }

        }
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            change = true;
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            select();
            //如果textbox1.text=username并且textbox2.text=password
            if (flag == true && change == true)//管理员要求账号密码正确
            {
                Form9 form = new Form9(textBox1.Text);
                form.Show();
                this.Hide();
            }
            else if (flag == true && flags == true)//读者要求全部输入正确
            {

                Form8 form = new Form8(textBox1.Text, textBox3.Text);
                form.Show();
                this.Hide();
            }
           else
               MessageBox.Show("登陆失败！！！");
            
            
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            change = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            

        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
