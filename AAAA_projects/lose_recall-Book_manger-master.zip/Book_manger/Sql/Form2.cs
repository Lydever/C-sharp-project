﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sql
{
    public partial class Form2 : Form
    {
       
        string user, Rno;
        
        public Form2(string u,string Rn)
        {
            InitializeComponent();
            user = u;
            Rno = Rn;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            label8.Text = user;
            label9.Text = Rno;
            BindGrid();
            timer1.Start();
            timer1_Tick(null,null);
        }

        private void  Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit(e);
        }

        void BindGrid()
        {
            SQL.Open();
            SqlCommand lo_cmd = new SqlCommand();
            lo_cmd.CommandText = "select B_name,B_writer,B_publish,B_price,B_class,Num_total,Num_remain from Book,Classfy where Book.Class_no=Classfy.Class_no";
            lo_cmd.Connection = SQL.conn;
            lo_cmd.ExecuteNonQuery();
            SqlDataAdapter dbAdapter = new SqlDataAdapter(lo_cmd);
            DataSet ds = new DataSet();
            dbAdapter.Fill(ds);
            SQL.Close();
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sqlInsert = "insert into Borrow values('"+Rno+ "','"+textBox1.Text+"', '"+ DateTime.Now.ToString("yyyy-MM-dd") + "', '"+textBox6.Text+"',"+ "null)";
            string sqlStr = "update Book set Num_remain=Num_remain-1 where B_name='" + textBox1.Text + "'";
            if(SQL.SqlInsert(sqlInsert)&& SQL.SqlUpdate(sqlStr))
            {
                Form2_Load(this, null);
                MessageBox.Show("借阅成功！！！");
            }
           
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
            getselectdata();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form8 form = new Form8(user, Rno);
            form.Show();
            this.Hide();
        }

        void getselectdata()
        {
            int a = dataGridView1.CurrentRow.Index;
            textBox1.Text = dataGridView1.Rows[a].Cells["B_name"].Value.ToString();
            textBox3.Text = dataGridView1.Rows[a].Cells["B_class"].Value.ToString();
            textBox2.Text = dataGridView1.Rows[a].Cells["B_price"].Value.ToString();
            textBox4.Text = dataGridView1.Rows[a].Cells["Num_total"].Value.ToString();
            textBox5.Text = dataGridView1.Rows[a].Cells["Num_remain"].Value.ToString();

        }
    }
}
