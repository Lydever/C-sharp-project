﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sql
{
    public partial class Form3 : Form
    {
        string Manger;
        public Form3(string M)
        {
            InitializeComponent();
            Manger = M;
        }
        void BindGrid()
        {
            try
            {
                SQL.Open();
                SqlCommand lo_cmd = new SqlCommand();
                lo_cmd.CommandText = "select * from Book,Classfy where Book.Class_no=Classfy.Class_no";
                lo_cmd.Connection = SQL.conn;
                lo_cmd.ExecuteNonQuery();
                SqlDataAdapter dbAdapter = new SqlDataAdapter(lo_cmd);
                DataSet ds = new DataSet();
                dbAdapter.Fill(ds);
                SQL.Close();
                dataGridView1.DataSource = ds.Tables[0];
            }
            catch
            {
                MessageBox.Show("异常");
            }
            
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            label2.Text = Manger;
            BindGrid();
            timer1.Start();
            timer1_Tick(null,null);
        }
        void getselectdata()
        {
            int a = dataGridView1.CurrentRow.Index;
            textBox1.Text = dataGridView1.Rows[a].Cells["B_name"].Value.ToString();
            //textBox6.Text = dataGridView1.Rows[a].Cells["B_writer"].Value.ToString();
            //textBox7.Text = dataGridView1.Rows[a].Cells["B_publish"].Value.ToString();
            //textBox2.Text = dataGridView1.Rows[a].Cells["B_price"].Value.ToString();
            //textBox3.Text = dataGridView1.Rows[a].Cells["Class_no"].Value.ToString();
            //textBox4.Text = dataGridView1.Rows[a].Cells["Num_total"].Value.ToString();
            //textBox5.Text = dataGridView1.Rows[a].Cells["Num_remain"].Value.ToString();

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            getselectdata();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string sqlInsert = "insert into Book values('" + textBox8.Text + "','" + textBox9.Text + "', '" + textBox10.Text + "', " + textBox12.Text + ",'" + textBox11.Text + "'," + textBox13.Text + "," + textBox13.Text + ")";
            //string sqlInsert = "insert into Book values('java','sd','sd',1,12,12,12)";
            if(SQL.SqlInsert(sqlInsert))
                MessageBox.Show("添加成功");
            Form3_Load(this, null);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sqlStr = "update Book set B_writer='"+ textBox6.Text+"',B_publish='"+ textBox7.Text + "',B_price='" + textBox2.Text
                + "',Class_no='" + textBox3.Text+ "',Num_total='" + textBox4.Text+"',Num_remain='" + textBox5.Text +"'where B_name='" + textBox1.Text + "'";
            if(SQL.SqlUpdate(sqlStr))
                MessageBox.Show("更新成功");
            Form3_Load(this, null);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string sqlStr ="delete from Book where B_name='"+ textBox1.Text+"'"; 
            if(SQL.SqlDelete(sqlStr))
                 MessageBox.Show("删除成功");
            Form3_Load(this, null);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form9 form = new Form9(Manger);
            form.Show();
            this.Hide();
        }

        private void Form3_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
